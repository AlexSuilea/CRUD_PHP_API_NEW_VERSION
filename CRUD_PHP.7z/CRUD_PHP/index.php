<?php 
    include "inc/header.php";
    include "config.php";
    include "Database.php";

    $db = new Database;
    $query = "SELECT * FROM php_user";
    $read = $db->select($query);
?>


<?php
    if(isset($_GET['msg']))
    {
        echo "<span style='color:green;'>".$_GET['msg']."</span>";
    }

?>
<table class="tmain">
    <tr>
        <th>SL</th>
        <th> Name </th>
        <th> Email </th>
        <th> Skill </th>
        <th> Action </th>
    </tr>
    <?php if($read){ ?>
    <?php
        $sl = 1;
         while($row = $read->fetch_assoc()){ ?>
    <tr>
        <td><?php echo $sl++; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['skill']; ?></td>
        <td><a class="btn btn-primary" href="update.php?id=<?php echo urlencode($row['id']); ?>"> Edit</td>
    </tr>
    <?php } ?>
    <?php } else { ?>
    <p>There is no data!</p>
    <?php } ?>
</table> 

<a class="btn btn-primary p-2 m-2" href="create.php">Create</a>


<?php include "inc/footer.php"; ?>